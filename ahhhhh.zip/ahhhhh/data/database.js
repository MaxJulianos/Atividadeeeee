
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');

const initDb = async () => {
    const db = await open({
        filename: './data/database.sqlite',
        driver: sqlite3.Database,
    });

    await db.exec(`
        CREATE TABLE IF NOT EXISTS discs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            year INTEGER,
            cover TEXT,
            tracks TEXT
        );
    `);

    await db.exec(`
        CREATE TABLE IF NOT EXISTS artists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            genre TEXT
        );
    `);

    await db.exec(`
        CREATE TABLE IF NOT EXISTS genres (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL
        );
    `);

    return db;
};

module.exports = (async () => {
    return await initDb();
})();
