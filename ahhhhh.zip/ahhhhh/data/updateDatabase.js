
const db = require('./data/database');

const updateAssociations = async () => {
    await db.exec(`
        CREATE TABLE IF NOT EXISTS disc_genre (
            disc_id INTEGER,
            genre_id INTEGER,
            FOREIGN KEY (disc_id) REFERENCES discs(id),
            FOREIGN KEY (genre_id) REFERENCES genres(id)
        );
    `);

    await db.exec(`
        CREATE TABLE IF NOT EXISTS artist_disc (
            artist_id INTEGER,
            disc_id INTEGER,
            FOREIGN KEY (artist_id) REFERENCES artists(id),
            FOREIGN KEY (disc_id) REFERENCES discs(id)
        );
    `);
};

updateAssociations();
