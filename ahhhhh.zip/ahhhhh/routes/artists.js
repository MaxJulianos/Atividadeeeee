
const express = require('express');
const router = express.Router();
const Artist = require('../models/artist');

// Get all artists
router.get('/', async (req, res) => {
    const artists = await Artist.getAll();
    res.render('artists', { artists });
});

// Add new artist
router.post('/add', async (req, res) => {
    const { name, genre } = req.body;
    await Artist.add({ name, genre });
    res.redirect('/artists');
});

module.exports = router;
