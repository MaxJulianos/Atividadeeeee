
const express = require('express');
const router = express.Router();
const Disc = require('../models/disc');

// Get all discs
router.get('/', async (req, res) => {
    const { title, artist, genre } = req.query;
    const discs = await Disc.search({ title, artist, genre });
    res.render('discs', { discs });
});

// Add new disc
router.post('/add', async (req, res) => {
    const { title, year, cover, tracks } = req.body;
    await Disc.add({ title, year, cover, tracks });
    res.redirect('/discs');
});

module.exports = router;
