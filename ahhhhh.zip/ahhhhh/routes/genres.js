
const express = require('express');
const router = express.Router();
const Genre = require('../models/genre');

// Get all genres
router.get('/', async (req, res) => {
    const genres = await Genre.getAll();
    res.render('genres', { genres });
});

// Add new genre
router.post('/add', async (req, res) => {
    const { name } = req.body;
    await Genre.add({ name });
    res.redirect('/genres');
});

module.exports = router;
