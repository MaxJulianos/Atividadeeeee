
const db = require('../data/database');

const Genre = {
    getAll: async () => {
        const rows = await db.all('SELECT * FROM genres');
        return rows;
    },
    add: async (genre) => {
        const { name } = genre;
        await db.run('INSERT INTO genres (name) VALUES (?)', [name]);
    },
};

module.exports = Genre;
