
const db = require('../data/database');

const Disc = {
    getAll: async () => {
        const rows = await db.all('SELECT * FROM discs');
        return rows;
    },
    add: async (disc) => {
        const { title, year, cover, tracks } = disc;
        await db.run('INSERT INTO discs (title, year, cover, tracks) VALUES (?, ?, ?, ?)', [
            title,
            year,
            cover,
            tracks,
        ]);
    },
    search: async ({ title, artist, genre }) => {
        let query = `SELECT DISTINCT d.* FROM discs d
                     LEFT JOIN artist_disc ad ON d.id = ad.disc_id
                     LEFT JOIN artists a ON ad.artist_id = a.id
                     LEFT JOIN disc_genre dg ON d.id = dg.disc_id
                     LEFT JOIN genres g ON dg.genre_id = g.id
                     WHERE 1=1`;

        const params = [];

        if (title) {
            query += ` AND d.title LIKE ?`;
            params.push(`%${title}%`);
        }
        if (artist) {
            query += ` AND a.name LIKE ?`;
            params.push(`%${artist}%`);
        }
        if (genre) {
            query += ` AND g.name LIKE ?`;
            params.push(`%${genre}%`);
        }

        return await db.all(query, params);
    },
};

module.exports = Disc;
