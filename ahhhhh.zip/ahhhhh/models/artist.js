
const db = require('../data/database');

const Artist = {
    getAll: async () => {
        const rows = await db.all('SELECT * FROM artists');
        return rows;
    },
    add: async (artist) => {
        const { name, genre } = artist;
        await db.run('INSERT INTO artists (name, genre) VALUES (?, ?)', [name, genre]);
    },
};

module.exports = Artist;
