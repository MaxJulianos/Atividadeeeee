
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Set view engine to EJS
app.set('view engine', 'ejs');

// Routes
const discRoutes = require('./routes/discs');
const artistRoutes = require('./routes/artists');
const genreRoutes = require('./routes/genres');

app.use('/discs', discRoutes);
app.use('/artists', artistRoutes);
app.use('/genres', genreRoutes);

// Home route
app.get('/', (req, res) => {
    res.render('index');
});

// Start the server
app.listen(port, () => {
    console.log(`Music Catalog App listening at http://localhost:${port}`);
});
